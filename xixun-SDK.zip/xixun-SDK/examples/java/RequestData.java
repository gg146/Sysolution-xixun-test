
public class RequestData {
	
	
	//第一步停止节目
	public String type="stopPlayer";
    public boolean stop = true;
	
	
	/*//第二步插播百度
	  public String type="loadUrl";
    public String url = "https://www.baidu.com";
   //（html文件可以放在服务器上，也可以放在本地）
    boolean persistent = false ;
	*/
	
	/*
	//第三步停止并清除插播
	public String type="clear";
	*/
	
	
	/*
	//第四步继续轮播节目
	public String type="stopPlayer";
    public boolean stop = false;
	*/
	
	
}
