How to test ?
1.open a cmd
2.enter the following command:
cd \Windows\Microsoft.NET\Framework64\v4.0.30319
csc /out:c:\test.exe /r:System.Web.Extensions.dll E:\realtimeSDK\realtimeSDK2\examples\C#\ScreenSwitch.cs

3.find c:\test.exe and run it.
