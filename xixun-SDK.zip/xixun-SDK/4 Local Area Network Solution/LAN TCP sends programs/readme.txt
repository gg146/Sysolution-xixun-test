1，测试配置工具Ledok，可以从熙讯官网下载：www.ledok.cn  软件下载第一个（必须下载官网全的，再安装文件里边定制ledok Express）；
2，保证控制卡播放器是xixunplayer1099-18以上，要是低版本，可以通过ledok软件，终端配置-高级设置(密码888)-升级xixunplayer(直接选择zip文件或者apk)；
3，ledok软件可以实现的功能，网关都可以移植完成。