# 		xixunPlayer program solution instructions

### If xwalk can not support some complicate display functions, please convert the program into xixunplayer format, which means using xixunplayer to display program. 



### playerDemo demonstrate image and display video in loop, the example will assit users to make program in short time so that no need to research the program structure in advance. 

### Instructions:

### copy res folder to the root of Disk C before running the project. This folder contains program template file and  necessary image and video. 

