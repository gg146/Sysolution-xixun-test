--------------1.2.0------------
1��delete all programs from xixunplayer