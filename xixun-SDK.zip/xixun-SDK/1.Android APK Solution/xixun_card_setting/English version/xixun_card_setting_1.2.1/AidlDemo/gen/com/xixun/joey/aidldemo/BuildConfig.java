/** Automatically generated file. DO NOT MODIFY */
package com.xixun.joey.aidldemo;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}