# Soultion Five: Vehicle HUB Solution

![image-20240708172142786](https://github.com/gg146/Sysolution-xixun-test/blob/master/xixun-SDK/2.Realtime%20Solution/java%20version%20(recommend)/image/12.jpg?raw=true)

##### Solution Introduction

Vehicle HUB solution is to log in to the platform through the return of the token, in the call api add the the key and value, so as to conduct secondary development docking. Secondary development API docking is required for customers to privatize the deploy platform, private deployment of API is required to charge, the specific costs please contact the sales staff